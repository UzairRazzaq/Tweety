<ul>
    <li><a
            class="font-bold text-lg mb-4 block"
            href="/"
        >Home</a></li>
    <li><a
            class="font-bold text-lg mb-4 block"
            href="/"
        >Explore</a></li>
    <li><a
            class="font-bold text-lg mb-4 block"
            href="/"
        >Notifications</a></li>
    <li><a
            class="font-bold text-lg mb-4 block"
            href="/"
        >Messages</a></li>
    <li><a
            class="font-bold text-lg mb-4 block"
            href="/"
        >Bookmarks</a></li>
    <li><a
            class="font-bold text-lg mb-4 block"
            href="/"
        >Lits</a></li>
    <li><a
            class="font-bold text-lg mb-4 block"
            href="/"
        >Profile</a></li>
    <li><a
            class="font-bold text-lg mb-4 block"
            href="/"
        >More</a></li>
</ul>
